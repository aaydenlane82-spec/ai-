# 🤖 AI Factory - GitHub Actions Edition

A **free, 24/7 AI idea generator** that runs automatically on GitHub Actions. No servers, no hosting costs, no maintenance.

## ✨ Features

- **Runs every 30 minutes** automatically (free GitHub Actions minutes)
- **Persistent memory** - remembers all generated ideas across runs
- **Streak tracking** - tracks consecutive days of runs
- **Focus modes** - balanced, world-changing, or rapid generation
- **Duplicate detection** - never generates the same idea twice
- **Detailed logging** - full history of all runs
- **Poe API ready** - add your API key for AI-powered generation

## 📁 Repository Structure

```
ai-factory-github/
├── runner.py              # Main AI generator script
├── state.json             # Persistent state (runs, streaks, etc.)
├── generated_ideas.json   # All generated ideas
├── run_logs.json          # Detailed run history
├── requirements.txt       # Python dependencies
├── README.md              # This file
└── .github/
    └── workflows/
        └── ai_runner.yml  # GitHub Actions workflow
```

## 🚀 Quick Setup

### 1. Create a new GitHub repository

1. Go to [github.com/new](https://github.com/new)
2. Name it `ai-factory` (or anything you like)
3. Make it **Public** (required for free Actions minutes)
4. Click **Create repository**

### 2. Upload these files

Upload all files from this folder to your new repository:
- Drag and drop files to the GitHub web interface, OR
- Use git:

```bash
git clone https://github.com/YOUR_USERNAME/ai-factory.git
cd ai-factory
# Copy all files from this folder here
git add .
git commit -m "Initial AI Factory setup"
git push
```

### 3. Enable GitHub Actions

1. Go to your repo → **Actions** tab
2. Click **"I understand my workflows, go ahead and enable them"**

### 4. (Optional) Add Poe API Key

For AI-powered generation instead of templates:

1. Get your API key from [poe.com/api_key](https://poe.com/api_key)
2. Go to your repo → **Settings** → **Secrets and variables** → **Actions**
3. Click **New repository secret**
4. Name: `POE_API_KEY`
5. Value: Your API key
6. Click **Add secret**

## 📊 How It Works

```
┌─────────────────────────────────────────────────────────────┐
│                    GitHub Actions Cron                       │
│                  (Every 30 minutes)                          │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────┐
│                    runner.py                                 │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ 1. Load state from state.json                        │   │
│  │ 2. Check for Poe API key                             │   │
│  │ 3. Generate idea (API or local templates)            │   │
│  │ 4. Check for duplicates                              │   │
│  │ 5. Save to generated_ideas.json                      │   │
│  │ 6. Update state and streaks                          │   │
│  │ 7. Print status report                               │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────┐
│                    Git Commit & Push                         │
│            (Saves progress to repository)                    │
└─────────────────────────────────────────────────────────────┘
```

## 🎮 Manual Run

Trigger a run anytime:

1. Go to **Actions** tab
2. Click **AI Factory Runner**
3. Click **Run workflow**
4. Choose focus mode:
   - `balanced` - Mix of all categories
   - `world-changing` - Only impactful ideas
   - `rapid` - Fast generation mode
5. Click **Run workflow**

## 📈 Viewing Results

### Check generated ideas:
Open `generated_ideas.json` in your repository

### Check run statistics:
Open `state.json` for:
- Total runs
- Ideas generated
- Current streak
- Focus mode

### Check run history:
Open `run_logs.json` for detailed logs

### View run summaries:
1. Go to **Actions** tab
2. Click any completed run
3. Scroll down to see the summary

## 🔧 Configuration

### Change run frequency

Edit `.github/workflows/ai_runner.yml`:

```yaml
schedule:
  - cron: "*/30 * * * *"  # Every 30 minutes
  # - cron: "0 * * * *"   # Every hour
  # - cron: "0 */6 * * *" # Every 6 hours
  # - cron: "0 0 * * *"   # Once daily at midnight
```

### Change focus mode permanently

Edit `state.json`:

```json
{
  "focus_mode": "world-changing"
}
```

Options: `balanced`, `world-changing`, `rapid`

## 📋 Idea Format

Each generated idea includes:

```json
{
  "id": "idea-0001",
  "hash": "abc123def456",
  "name": "Health App #1",
  "description": "AI-powered symptom tracker with personalized health insights",
  "category": "health",
  "complexity": "world-changing",
  "focus": "healthcare accessibility",
  "features": [
    "Real-time notifications",
    "AI-powered insights",
    "Offline mode support",
    "Privacy-focused design"
  ],
  "revenue_model": "Freemium with premium features",
  "generated_at": "2024-01-15T10:30:00.000000",
  "run_number": 42,
  "status": "new",
  "priority_score": 87
}
```

## 🆓 GitHub Actions Limits

For **public repositories**:
- **Unlimited** free minutes
- Runs can be up to 6 hours each

For **private repositories**:
- 2,000 free minutes/month (GitHub Free)
- 3,000 free minutes/month (GitHub Pro)

At 30-minute intervals, you'll use:
- ~48 runs/day × ~1 min each = ~48 minutes/day
- ~1,440 minutes/month

**Recommendation**: Keep the repo **public** for unlimited free runs.

## 🔮 Future Upgrades

Coming soon (tell me which you want!):

1. 🧠 **Smarter memory** - Long-term planning and idea evolution
2. 🔁 **Multi-account rotation** - Distribute API calls
3. 🚀 **Auto code generation** - Turn ideas into real apps
4. 📈 **Quality filtering** - Only keep world-changing ideas
5. 📊 **Dashboard** - Web UI to view all ideas
6. 🔔 **Notifications** - Email/Discord alerts for new ideas

## ❓ Troubleshooting

### Actions not running?
- Check that Actions are enabled in your repo settings
- For scheduled runs, the repo must have activity in the last 60 days

### Commits failing?
- Make sure the workflow has write permissions
- Check **Settings** → **Actions** → **General** → **Workflow permissions**
- Select **Read and write permissions**

### No ideas generating?
- Check run logs in **Actions** tab
- Verify `state.json` is valid JSON

## 📄 License

MIT License - Use freely for any purpose!

---

Built with 🤖 by AI Factory

*Start generating world-changing ideas today!*
