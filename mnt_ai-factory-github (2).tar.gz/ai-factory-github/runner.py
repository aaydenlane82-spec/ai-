#!/usr/bin/env python3
"""
AI Factory Runner - GitHub Actions Edition
Runs on a schedule, generates AI-powered app ideas and upgrade plans.
Uses Poe API for intelligent generation, maintains state between runs.
"""

import json
import os
import sys
import time
import random
import hashlib
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List

# Optional: Poe API integration (uncomment when ready)
# import requests

STATE_FILE = "state.json"
IDEAS_FILE = "generated_ideas.json"
LOG_FILE = "run_logs.json"

# Categories for app generation
CATEGORIES = [
    "health", "finance", "education", "productivity",
    "social", "ecommerce", "entertainment", "travel",
    "sustainability", "ai", "gaming", "creative"
]

# Complexity levels
COMPLEXITY_LEVELS = ["simple", "moderate", "advanced", "world-changing"]

# Focus areas for world-changing ideas
WORLD_CHANGING_FOCUS = [
    "climate change solutions",
    "healthcare accessibility",
    "education equality",
    "mental health support",
    "food security",
    "clean energy",
    "poverty reduction",
    "disaster response",
    "accessibility tools",
    "community building"
]


def load_json(filepath: str, default: Any = None) -> Any:
    """Load JSON file with fallback to default."""
    if os.path.exists(filepath):
        try:
            with open(filepath, "r") as f:
                return json.load(f)
        except json.JSONDecodeError:
            print(f"[WARN] Corrupted {filepath}, using default")
    return default if default is not None else {}


def save_json(filepath: str, data: Any) -> None:
    """Save data to JSON file."""
    with open(filepath, "w") as f:
        json.dump(data, f, indent=2, default=str)


def get_state() -> Dict[str, Any]:
    """Load or initialize state."""
    default_state = {
        "runs": 0,
        "total_ideas_generated": 0,
        "last_run": None,
        "streak_days": 0,
        "last_streak_date": None,
        "focus_mode": "balanced",  # balanced, world-changing, rapid
        "current_project": None,
        "credits_used_estimate": 0,
        "version": "1.0.0"
    }
    state = load_json(STATE_FILE, default_state)
    # Merge with defaults for new fields
    for key, value in default_state.items():
        if key not in state:
            state[key] = value
    return state


def save_state(state: Dict[str, Any]) -> None:
    """Save state to file."""
    save_json(STATE_FILE, state)


def get_ideas() -> List[Dict[str, Any]]:
    """Load generated ideas."""
    return load_json(IDEAS_FILE, [])


def save_ideas(ideas: List[Dict[str, Any]]) -> None:
    """Save ideas to file."""
    save_json(IDEAS_FILE, ideas)


def add_log(message: str, level: str = "info") -> None:
    """Add entry to run log."""
    logs = load_json(LOG_FILE, [])
    logs.append({
        "timestamp": datetime.utcnow().isoformat(),
        "level": level,
        "message": message
    })
    # Keep only last 1000 entries
    if len(logs) > 1000:
        logs = logs[-1000:]
    save_json(LOG_FILE, logs)
    print(f"[{level.upper()}] {message}")


def generate_idea_hash(idea: Dict) -> str:
    """Generate unique hash for an idea to prevent duplicates."""
    content = f"{idea.get('name', '')}{idea.get('description', '')}"
    return hashlib.md5(content.encode()).hexdigest()[:12]


def call_poe_api(prompt: str, bot: str = "GPT-5.1") -> Optional[str]:
    """
    Call Poe API to generate content.

    SETUP REQUIRED:
    1. Get your Poe API key from poe.com/api_key
    2. Add it as a GitHub secret named POE_API_KEY

    For now, this returns a placeholder. Uncomment the real implementation
    when you have your API key set up.
    """
    api_key = os.environ.get("POE_API_KEY")

    if not api_key:
        add_log("POE_API_KEY not set - using local generation", "warn")
        return None

    # TODO: Implement real Poe API call
    # The Poe API uses a different protocol (fastapi_poe)
    # For now, we'll use local generation
    #
    # Real implementation would look like:
    # try:
    #     import fastapi_poe as fp
    #     # Use the Poe client
    #     response = await fp.get_bot_response(
    #         messages=[fp.ProtocolMessage(role="user", content=prompt)],
    #         bot_name=bot,
    #         api_key=api_key
    #     )
    #     return response
    # except Exception as e:
    #     add_log(f"Poe API error: {e}", "error")
    #     return None

    add_log("Poe API integration placeholder - implement with fastapi_poe", "info")
    return None


def generate_local_idea(state: Dict, existing_ideas: List[Dict]) -> Dict[str, Any]:
    """Generate an app idea locally (without API)."""

    # Determine focus based on mode
    if state.get("focus_mode") == "world-changing":
        category = random.choice(["sustainability", "health", "education", "ai"])
        focus = random.choice(WORLD_CHANGING_FOCUS)
        complexity = "world-changing"
    else:
        category = random.choice(CATEGORIES)
        focus = None
        complexity = random.choice(COMPLEXITY_LEVELS)

    # Generate unique idea number
    idea_num = len(existing_ideas) + 1

    # Templates for different categories
    templates = {
        "health": [
            "AI-powered symptom tracker with personalized health insights",
            "Mental wellness companion with mood tracking and CBT exercises",
            "Medication reminder with drug interaction checker",
            "Sleep optimization app with smart alarm features",
            "Fitness planner with adaptive workout recommendations"
        ],
        "finance": [
            "Budget tracker with AI spending predictions",
            "Investment portfolio analyzer with risk assessment",
            "Bill splitting app with recurring payment tracking",
            "Crypto portfolio manager with market alerts",
            "Savings goal tracker with automated recommendations"
        ],
        "education": [
            "Adaptive learning platform with spaced repetition",
            "Language learning app with speech recognition",
            "Study group coordinator with shared notes",
            "Flashcard maker with AI-generated questions",
            "Skill assessment tool with personalized learning paths"
        ],
        "productivity": [
            "Smart task manager with priority optimization",
            "Focus timer with distraction blocking",
            "Meeting scheduler with timezone intelligence",
            "Note-taking app with AI summarization",
            "Habit tracker with streak analytics"
        ],
        "social": [
            "Interest-based community platform",
            "Event discovery app with friend coordination",
            "Anonymous support group connector",
            "Skill exchange marketplace",
            "Neighborhood helper network"
        ],
        "sustainability": [
            "Carbon footprint tracker with reduction tips",
            "Sustainable product scanner with alternatives",
            "Community garden coordinator",
            "Energy usage optimizer for homes",
            "Plastic waste reduction challenge app"
        ],
        "ai": [
            "Personal AI assistant with learning capabilities",
            "Document analyzer with insight extraction",
            "Code review assistant with best practices",
            "Creative writing partner with style adaptation",
            "Data visualization generator from natural language"
        ]
    }

    # Get template or generate generic
    cat_templates = templates.get(category, [
        f"Innovative {category} solution with AI features",
        f"Smart {category} platform with user personalization",
        f"Community-driven {category} application"
    ])

    base_idea = random.choice(cat_templates)

    # Add world-changing modifier if applicable
    if focus:
        base_idea = f"{base_idea} focused on {focus}"

    # Generate features
    feature_pool = [
        "Real-time notifications",
        "Offline mode support",
        "Data export/import",
        "Social sharing",
        "Analytics dashboard",
        "Customizable themes",
        "Multi-language support",
        "Accessibility features",
        "Cloud sync",
        "AI-powered insights",
        "Voice control",
        "Widget support",
        "Cross-platform sync",
        "Privacy-focused design"
    ]

    features = random.sample(feature_pool, min(4, len(feature_pool)))

    # Revenue models
    revenue_models = [
        "Freemium with premium features",
        "Subscription-based",
        "One-time purchase",
        "Ad-supported free tier",
        "B2B licensing",
        "Marketplace commission"
    ]

    idea = {
        "id": f"idea-{idea_num:04d}",
        "hash": None,  # Will be set after
        "name": f"{category.title()} App #{idea_num}",
        "description": base_idea,
        "category": category,
        "complexity": complexity,
        "focus": focus,
        "features": features,
        "revenue_model": random.choice(revenue_models),
        "generated_at": datetime.utcnow().isoformat(),
        "run_number": state.get("runs", 0) + 1,
        "status": "new",
        "priority_score": random.randint(1, 100)
    }

    # Calculate priority boost for world-changing ideas
    if complexity == "world-changing":
        idea["priority_score"] = min(100, idea["priority_score"] + 30)

    idea["hash"] = generate_idea_hash(idea)

    return idea


def generate_upgrade_plan(state: Dict, ideas: List[Dict]) -> str:
    """Generate an upgrade plan for the AI factory itself."""

    runs = state.get("runs", 0)
    total_ideas = len(ideas)

    # Milestones
    milestones = []
    if runs >= 10:
        milestones.append("10+ runs completed")
    if runs >= 50:
        milestones.append("50+ runs - veteran status")
    if runs >= 100:
        milestones.append("100+ runs - master generator")
    if total_ideas >= 25:
        milestones.append("25+ ideas in library")
    if total_ideas >= 100:
        milestones.append("100+ ideas - idea factory")

    # Calculate world-changing ratio
    world_changing = [i for i in ideas if i.get("complexity") == "world-changing"]
    wc_ratio = len(world_changing) / max(1, total_ideas) * 100

    # Generate recommendations
    recommendations = []

    if wc_ratio < 20:
        recommendations.append("Consider switching to 'world-changing' focus mode")

    if runs > 20 and total_ideas < runs:
        recommendations.append("Some runs may have failed - check logs")

    if state.get("streak_days", 0) < 3:
        recommendations.append("Build consistency with daily runs")

    # High-value recommendations based on state
    if total_ideas > 50:
        recommendations.append("Review and prioritize top ideas for development")

    plan = f"""
╔══════════════════════════════════════════════════════════════╗
║                    AI FACTORY STATUS REPORT                   ║
╚══════════════════════════════════════════════════════════════╝

📊 STATISTICS
────────────────────────────────────────────────────────────────
  Total Runs:           {runs + 1}
  Ideas Generated:      {total_ideas}
  World-Changing Ideas: {len(world_changing)} ({wc_ratio:.1f}%)
  Current Focus Mode:   {state.get('focus_mode', 'balanced')}
  Streak Days:          {state.get('streak_days', 0)}

🏆 MILESTONES ACHIEVED
────────────────────────────────────────────────────────────────
{chr(10).join('  ✓ ' + m for m in milestones) if milestones else '  (Keep running to unlock milestones!)'}

💡 RECOMMENDATIONS
────────────────────────────────────────────────────────────────
{chr(10).join('  → ' + r for r in recommendations) if recommendations else '  ✓ Everything looks great!'}

🔮 NEXT STEPS
────────────────────────────────────────────────────────────────
  1. Review generated ideas in generated_ideas.json
  2. Prioritize high-scoring world-changing ideas
  3. Consider implementing top ideas as real apps
  4. Add Poe API key for AI-powered generation

⏰ Report Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC
════════════════════════════════════════════════════════════════
"""

    return plan


def update_streak(state: Dict) -> Dict:
    """Update run streak tracking."""
    today = datetime.utcnow().date().isoformat()
    last_date = state.get("last_streak_date")

    if last_date:
        last = datetime.fromisoformat(last_date).date()
        today_date = datetime.utcnow().date()
        diff = (today_date - last).days

        if diff == 0:
            # Same day, streak continues
            pass
        elif diff == 1:
            # Next day, increment streak
            state["streak_days"] = state.get("streak_days", 0) + 1
        else:
            # Streak broken
            state["streak_days"] = 1
    else:
        state["streak_days"] = 1

    state["last_streak_date"] = today
    return state


def main():
    """Main runner function."""
    print("\n" + "="*60)
    print("🤖 AI FACTORY - GitHub Actions Runner")
    print("="*60 + "\n")

    # Load state
    state = get_state()
    ideas = get_ideas()

    add_log(f"Starting run #{state['runs'] + 1}")

    # Update streak
    state = update_streak(state)

    # Check for focus mode from environment
    focus_override = os.environ.get("AI_FOCUS_MODE")
    if focus_override:
        state["focus_mode"] = focus_override
        add_log(f"Focus mode set to: {focus_override}")

    # Try Poe API first, fall back to local
    poe_response = call_poe_api(
        "Generate an innovative app idea that could change the world.",
        bot="GPT-5.1"
    )

    if poe_response:
        # Parse Poe response into idea format
        # TODO: Implement proper parsing
        add_log("Using Poe API response", "info")
        idea = {
            "id": f"idea-poe-{len(ideas) + 1:04d}",
            "name": "Poe Generated Idea",
            "description": poe_response,
            "category": "ai",
            "complexity": "advanced",
            "generated_at": datetime.utcnow().isoformat(),
            "source": "poe-api",
            "status": "new"
        }
    else:
        # Generate locally
        idea = generate_local_idea(state, ideas)
        add_log(f"Generated local idea: {idea['name']}")

    # Check for duplicates
    existing_hashes = {i.get("hash") for i in ideas if i.get("hash")}
    if idea.get("hash") not in existing_hashes:
        ideas.append(idea)
        save_ideas(ideas)
        add_log(f"Saved new idea #{len(ideas)}: {idea['description'][:50]}...")
        state["total_ideas_generated"] = len(ideas)
    else:
        add_log("Duplicate idea detected, skipping save", "warn")

    # Generate and print upgrade plan
    plan = generate_upgrade_plan(state, ideas)
    print(plan)

    # Update state
    state["runs"] += 1
    state["last_run"] = datetime.utcnow().isoformat()
    save_state(state)

    add_log(f"Run #{state['runs']} completed successfully")

    # Summary
    print(f"\n✅ Run completed!")
    print(f"   Ideas in library: {len(ideas)}")
    print(f"   Total runs: {state['runs']}")
    print(f"   Streak: {state['streak_days']} days")

    return 0


if __name__ == "__main__":
    sys.exit(main())
